package com.example.timemanagementapp

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val btnDatePicker: Button = findViewById(R.id.button)
        btnDatePicker.setOnClickListener {
            clickDatePicker()
        }
        val btnDatePicker1: Button = findViewById(R.id.button2)
        btnDatePicker1.setOnClickListener {
            clickDatePicker1()
        }
        val btnDatePicker2: Button = findViewById(R.id.button3)
        btnDatePicker2.setOnClickListener {
            clickDatePicker2()
        }
    }

    fun clickDatePicker2() {
        val editTextNumber: EditText = findViewById(R.id.editTextNumber)
        val tvSelectedDateInMinutes: TextView = findViewById(R.id.textView2)
        val hoursOfSleep = editTextNumber.text.toString().toInt()
        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)
        val theDate = sdf.parse(selectedDate2)
        theDate?.let {
            val selectedDateInMinutes = theDate.time / 60000 / 60
            tvSelectedDateInMinutes.text = selectedDateInMinutes.toString()
            val theDate1 = sdf.parse(selectedDate)
            theDate1?.let {
                val selectedDateInMinutes1 = theDate1.time / 60000 / 60
                val sel = selectedDateInMinutes1.toString().toInt()
                val differenceInMinutes = (selectedDateInMinutes - sel) - (selectedDateInMinutes - sel)/24*(8+hoursOfSleep)
                tvSelectedDateInMinutes.text = differenceInMinutes.toString()
            }
        }
    }

    var selectedDate = "2/2/2022"
    fun clickDatePicker() {
        val myCalendar = Calendar.getInstance()
        val year = myCalendar.get(Calendar.YEAR)
        val month = myCalendar.get(Calendar.MONTH)
        val day = myCalendar.get(Calendar.DAY_OF_MONTH)
        val tvSelectedDate: TextView = findViewById(R.id.textView)
        val dpd = DatePickerDialog(
            this, { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                selectedDate = "$selectedDayOfMonth/${selectedMonth + 1}/$selectedYear"
                tvSelectedDate.text = selectedDate

            },
            year, month, day
        )
        dpd.datePicker.maxDate = System.currentTimeMillis() - 86400000
        dpd.show()
    }

    var selectedDate2 = "2/2/2022"
    fun clickDatePicker1() {
        val myCalendar = Calendar.getInstance()
        val year = myCalendar.get(Calendar.YEAR)
        val month = myCalendar.get(Calendar.MONTH)
        val day = myCalendar.get(Calendar.DAY_OF_MONTH)

        val tvSelectedDate: TextView = findViewById(R.id.textView3)
        val dpd1 = DatePickerDialog(
            this, { _, selectedYear, selectedMonth, selectedDayOfMonth ->
                selectedDate2 = "$selectedDayOfMonth/${selectedMonth + 1}/$selectedYear"
                tvSelectedDate.text = selectedDate2
            },
            year, month, day
        )
        dpd1.datePicker.minDate = System.currentTimeMillis() - 86400000
        dpd1.show()
    }
}


    /*val selectedDateInMinutes = theDate.time/60000
    val currentDate = sdf.parse(sdf.format(System.currentTimeMillis()))
    currentDate?.let {
        val currentDateToMinutes = currentDate.time/60000
        val differenceInMinutes = currentDateToMinutes - selectedDateInMinutes
        tvSelectedDateInMinutes.text = differenceInMinutes.toString()*/

